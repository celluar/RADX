# RADX
Relativity Adjusted (?) Disk 


Corrective code for disk spectrum applying Doppler shift and relativistic effects using iron lines.

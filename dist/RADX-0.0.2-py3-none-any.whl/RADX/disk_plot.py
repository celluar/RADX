from numpy import random
from matplotlib import pyplot as plt
%matplotlib inline
import numpy as np
import matplotlib.pyplot as plt
from numpy import cos, sqrt, sin
from matplotlib import cm

